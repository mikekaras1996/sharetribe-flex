import Footer from './Footer';
import css from './FooterExample.css';

export const Default = {
  component: Footer,
  props: { className: css.example },
};
