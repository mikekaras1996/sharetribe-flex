import IconSpinner from './IconSpinner';

export const Icon = {
  component: IconSpinner,
  props: {},
  group: 'icons',
};
