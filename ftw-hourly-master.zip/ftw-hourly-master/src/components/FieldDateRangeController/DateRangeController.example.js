import DateRangeController from './DateRangeController';

export const DateRangeControllerExample = {
  component: DateRangeController,
  props: {},
  group: 'custom inputs',
};
