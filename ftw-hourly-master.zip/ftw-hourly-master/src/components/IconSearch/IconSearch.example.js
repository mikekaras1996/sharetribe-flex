import IconSearch from './IconSearch';

export const Icon = {
  component: IconSearch,
  props: {},
  group: 'icons',
};
