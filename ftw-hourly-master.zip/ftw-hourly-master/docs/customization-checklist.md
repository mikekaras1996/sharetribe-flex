# Customization checklist

Documentation moved to the Flex Docs site:

https://www.sharetribe.com/docs/guides/ftw-customization-checklist/
