# Extend listing data

Documentation moved to the Flex Docs site:

https://www.sharetribe.com/docs/guides/how-to-extend-listing-data-in-ftw/
